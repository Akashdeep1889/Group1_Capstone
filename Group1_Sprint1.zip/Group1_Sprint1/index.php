<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>HomePage- Hamilton e-commerce</title>
  <link rel="stylesheet" href="css/styles.css">
  <link rel="stylesheet" href="css/mobile.css">
  <link rel="stylesheet" href="css/tablet.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
</head>
<body>

  <header>
    <div class="header">
      <div class="logo">
        <a href="index.php">
          <img src="imgs/logo.png" alt="Hamilton E-commerce Logo" class="logo-img">
        </a>
      </div>
        <h1>Hamilton E-commerce</h1>
        <div class="SearchBar">
          <input type="text" placeholder="Clothes">
          <button type="button">Search</button>
        </div>
      </div>
    
      <nav>
        <ul>
          <li><a href="index.php">Home</a></li>
          <li><a href="products.php">Products</a></li>
          <li><a href="">Cart</a></li>
          <li><a href="">About</a></li>
          <li><a href="auth.php">SignIn </a></li>
        </ul>
      </nav>
   
      
    </div>

    </div>
   
  </header>
  <div class="hero-image"></div>
  <div class="hero-text">
    <h2>Shop Quality Products at Unbeatable Prices!</h2>
  </div>
  <main>








    
  </main>

  <footer>
    <div class="Footer">
      <div class="Footer-links">
        <h5>Quick Links</h5>
        <ul>
          <li><a href="index.php">Home</a></li>
          <li><a href="products.php">Products</a></li>
          <li><a href="">About Us</a></li>
          <li><a href="">Contact</a></li>
       
        </ul>
      </div>
      <div class="footer-contact">
        <h5>Contact Us</h5>
        <p>123 Street, Hamilton, ON</p>
        <p>+1 123 000 7800</p>
      </div>
      
      
      <div class="footer-logo">
        <a href="index.php">
          <img src="imgs/logo.png" alt="Hamilton E-commerce Logo" class="logo-img">
        </a>
      </div>
      <div class="footer-social">
        <h5>Follow Us</h5>
        <a href="https://facebook.com" target=""><i class="fab fa-facebook"></i></a>
        <a href="https://twitter.com" target=""><i class="fab fa-twitter"></i></a>
        <a href="https://instagram.com" target=""><i class="fab fa-instagram"></i></a>
        <a href="https://linkedin.com" target=""><i class="fab fa-linkedin"></i></a>
      </div>
    </div>
  </footer>
  

</body>
</html>
