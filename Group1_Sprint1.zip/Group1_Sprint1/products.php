<?php
// Database connection
$conn = new mysqli('localhost', 'root', '', 'store_db');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch products from the database
$sql = "SELECT * FROM products";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Listings</title>

         <link rel="stylesheet" href="css/styles.css">
         <link rel="stylesheet" href="css/product.css">
   
</head>
<body>
<header>
    <div class="header">
      <div class="logo">
        <a href="index.html">
          <img src="imgs/logo.png" alt="Hamilton E-commerce Logo" class="logo-img">
        </a>
      </div>
        <h1>Hamilton E-commerce</h1>
        <div class="SearchBar">
          <input type="text" placeholder="Clothes">
          <button type="button">Search</button>
        </div>
      </div>
    
      <nav>
        <ul>
          <li><a href="index.php">Home</a></li>
          <li><a href="products.php">Products</a></li>
          <li><a href="">Cart</a></li>
          <li><a href="">About</a></li>
          <li><a href="auth.php">Signup</a></li>
        </ul>
      </nav>
   
      
    </div>

    </div>
   
  </header>
<div class="container">
    <h1>Products</h1>
    <div class="product-grid">
        <?php while ($row = $result->fetch_assoc()): ?>
            <div class="product">
                <img src="<?php echo $row['image']; ?>" alt="<?php echo $row['title']; ?>">
                <h2><?php echo $row['title']; ?></h2>
                <p>Price: $<?php echo $row['price']; ?></p>
                <a href="product.php?id=<?php echo $row['id']; ?>">View Details</a>
            </div>
        <?php endwhile; ?>
    </div>
</div>
<footer>
    <div class="Footer">
      <div class="Footer-links">
        <h5>Quick Links</h5>
        <ul>
        <li><a href="index.php">Home</a></li>
          <li><a href="products.php">Products</a></li>
          <li><a href="">About Us</a></li>
          <li><a href="">Contact</a></li>
         
        </ul>
      </div>
      <div class="footer-contact">
        <h5>Contact Us</h5>
        <p>123 Street, Hamilton, ON</p>
        <p>+1 123 000 7800</p>
      </div>
      
      
      <div class="footer-logo">
        <a href="index.html">
          <img src="imgs/logo.png" alt="Hamilton E-commerce Logo" class="logo-img">
        </a>
      </div>
      <div class="footer-social">
        <h5>Follow Us</h5>
        <a href="https://facebook.com" target=""><i class="fab fa-facebook"></i></a>
        <a href="https://twitter.com" target=""><i class="fab fa-twitter"></i></a>
        <a href="https://instagram.com" target=""><i class="fab fa-instagram"></i></a>
        <a href="https://linkedin.com" target=""><i class="fab fa-linkedin"></i></a>
      </div>
    </div>
  </footer>
  
</body>
</html>

<?php
$conn->close();
?>
