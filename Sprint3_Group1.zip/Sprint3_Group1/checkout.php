<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Checkout - Hamilton E-commerce</title>
  <link rel="stylesheet" href="css/styles.css">
  <link rel="stylesheet" href="css/checkout.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script>
    
    $(document).ready(function() {
      $("form").on("submit", function(event) {
        let valid = true;
        $("input[required]").each(function() {
          if ($(this).val() === "") {
            $(this).css("border", "2px solid red");
            valid = false;
          } else {
            $(this).css("border", "1px solid #ccc");
          }
        });

        
        let cardNumber = $("#cardNumber").val();
        if (!/^\d{16}$/.test(cardNumber)) {
          alert("Please enter a valid 16-digit card number.");
          valid = false;
        }

        
        let expiryDate = $("#expiryDate").val();
        if (!/^(0[1-9]|1[0-2])\/\d{2}$/.test(expiryDate)) {
          alert("Please enter a valid expiry date (MM/YY).");
          valid = false;
        }

        
        let cvv = $("#cvv").val();
        if (!/^\d{3}$/.test(cvv)) {
          alert("Please enter a valid 3-digit CVV.");
          valid = false;
        }

        if (!valid) {
          event.preventDefault();
        }
      });
    });
  </script>
</head>
<body>

<?php
session_start();
$conn = new mysqli('localhost', 'root', '', 'store_db');


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


if (!isset($_SESSION['user_id'])) {
    header("Location: auth.php");
    exit();
}


$cart_items = [];
$total_price = 0;

$cart_sql = "SELECT c.id, p.title, p.price, p.image, c.quantity 
             FROM cart c 
             JOIN products p ON c.product_id = p.id 
             WHERE c.user_id = ?";
$cart_stmt = $conn->prepare($cart_sql);
$cart_stmt->bind_param("i", $_SESSION['user_id']);
$cart_stmt->execute();
$cart_result = $cart_stmt->get_result();

while ($row = $cart_result->fetch_assoc()) {
    $cart_items[] = $row;
    $total_price += $row['price'] * $row['quantity'];
}
?>

<header>
    <div class="header">
        <div class="logo">
            <a href="index.php">
                <img src="imgs/logo.png" alt="Hamilton E-commerce Logo" class="logo-img">
            </a>
        </div>

        <h1>Hamilton E-commerce</h1>

        <div class="SearchBar">
            <input type="text" placeholder="Clothes">
            <button type="button">Search</button>
        </div>
    </div>

    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="products.php">Products</a></li>
            <li><a href="about.php">About Us</a></li>
            <li><a href="checkout.php">Checkout</a></li>
            <li><a href="contact.php">Contact</a></li>
            <?php if (isset($_SESSION['user_id'])): ?>
                <li><a href="logout.php">Logout</a></li>
            <?php else: ?>
                <li><a href="auth.php">SignIn</a></li>
            <?php endif; ?>
        </ul>
    </nav>

    <div class="user-welcome">
        <?php if (isset($_SESSION['first_name'])): ?>
            <span>&nbsp;&nbsp;&nbsp;Welcome <?php echo htmlspecialchars($_SESSION['first_name']); ?></span>
        <?php endif; ?>

        <!-- Cart Icon -->
        <div class="cart-icon">
            <a href="cart.php" style="text-decoration: none; color: inherit;">
                <i class="fas fa-shopping-cart"></i>
                <?php
                // Fetch the total number of items in the cart
                $user_id = $_SESSION['user_id'] ?? 0;
                $cart_count = 0;

                if ($user_id) {
                    $cart_count_sql = "SELECT SUM(quantity) as total_items FROM cart WHERE user_id = ?";
                    $cart_count_stmt = $conn->prepare($cart_count_sql);
                    $cart_count_stmt->bind_param("i", $user_id);
                    $cart_count_stmt->execute();
                    $cart_count_result = $cart_count_stmt->get_result();
                    $cart_data = $cart_count_result->fetch_assoc();
                    $cart_count = $cart_data['total_items'] ?? 0;
                }
                ?>
                <span class="cart-count">(<?php echo $cart_count; ?>)</span>
            </a>
        </div>
    </div>
</header>

<main>
  <div class="checkout-container">
    <h2>Checkout</h2>

    <div class="cart-overview">
      <h3>Your Cart</h3>
      <?php if (empty($cart_items)): ?>
        <p>Your cart is empty. Please add items to proceed.</p>
      <?php else: ?>
        <div class="cart-items-container">
          <?php foreach ($cart_items as $item): ?>
            <div class="cart-item">
              <div class="cart-item-image">
                <img src="images/<?php echo $item['image']; ?>" alt="<?php echo $item['title']; ?>" class="product-image">
              </div>
              <div class="cart-item-details">
                <p class="product-title"><?php echo htmlspecialchars($item['title']); ?></p>
                <p class="product-price">$<?php echo number_format($item['price'], 2); ?></p>
                <p class="product-quantity">Quantity: <?php echo $item['quantity']; ?></p>
                <p class="product-total">Total: $<?php echo number_format($item['price'] * $item['quantity'], 2); ?></p>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
        <div class="cart-total">
          <strong>Total: $<?php echo number_format($total_price, 2); ?></strong>
        </div>
      <?php endif; ?>
    </div>

    <form action="process_checkout.php" method="POST" class="checkout-form">
      <section class="billing-info">
        <h3>Billing Information</h3>
        <label for="fullName">Full Name</label>
        <input type="text" id="fullName" name="fullName" required>
        <label for="email">Email</label>
        <input type="email" id="email" name="email" required>
        <label for="address">Address</label>
        <input type="text" id="address" name="address" required>
        <label for="city">City</label>
        <input type="text" id="city" name="city" required>
        <label for="postalCode">Postal Code</label>
        <input type="text" id="postalCode" name="postalCode" required>
        <label for="phone">Phone Number</label>
        <input type="tel" id="phone" name="phone" required>
      </section>
      <section class="payment-info">
        <h3>Payment Information</h3>
        <label for="cardName">Cardholder Name</label>
        <input type="text" id="cardName" name="cardName" required>
        <label for="cardNumber">Card Number</label>
        <input type="text" id="cardNumber" name="cardNumber" pattern="\d{16}" placeholder="16-digit card number" required>
        <label for="expiryDate">Expiry Date</label>
        <input type="text" id="expiryDate" name="expiryDate" placeholder="MM/YY" required>
        <label for="cvv">CVV</label>
        <input type="text" id="cvv" name="cvv" pattern="\d{3}" placeholder="3-digit code" required>
      </section>
      <a href="payment_confirmation.php" class="place-order-button">Place Order</a>
    </form>
  </div>
</main>



  
  <footer>
    <div class="Footer">
      <div class="Footer-links">
        <h5>Quick Links</h5>
        <ul>
          <li><a href="index.php">Home</a></li>
          <li><a href="products.php">Products</a></li>
          <li><a href="about.php">About Us</a></li>
          <li><a href="contact.php">Contact</a></li>
        </ul>
      </div>
      <div class="footer-contact">
        <h5>Contact Us</h5>
        <p>123 Street, Hamilton, ON</p>
        <p>+1 123 000 7800</p>
      </div>
      
      <div class="footer-logo">
        <a href="index.php">
          <img src="imgs/logo.png" alt="Hamilton E-commerce Logo" class="logo-img">
        </a>
      </div>
      <div class="footer-social">
        <h5>Follow Us</h5>
        <a href="https://facebook.com" target=""><i class="fab fa-facebook"></i></a>
        <a href="https://twitter.com" target=""><i class="fab fa-twitter"></i></a>
        <a href="https://instagram.com" target=""><i class="fab fa-instagram"></i></a>
        <a href="https://linkedin.com" target=""><i class="fab fa-linkedin"></i></a>
      </div>
    </div>
  </footer>

</body>
</html>
