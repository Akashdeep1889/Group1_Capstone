<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Payment Confirmation - Hamilton E-commerce</title>
  <link rel="stylesheet" href="css/styles.css">
  <link rel="stylesheet" href="css/mobile.css">
  <link rel="stylesheet" href="css/tablet.css">
  <link rel="stylesheet" href="css/signin.css">
  <link rel="stylesheet" href="css/checkout.css">
  <link rel="stylesheet" href="css/contact.css">
  <link rel="stylesheet" href="css/payment.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
  
<?php
session_start();
?>

<header>

    <div class="header">
        <div class="logo">
            <a href="index.php">
                <img src="imgs/logo.png" alt="Hamilton E-commerce Logo" class="logo-img">
            </a>
        </div>
        <h1>Hamilton E-commerce</h1>
        <div class="SearchBar">
            <input type="text" placeholder="Clothes">
            <button type="button">Search</button>
        </div>
    </div>

    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="products.php">Products</a></li>
            <li><a href="about.php">About Us</a></li>
            <li><a href="checkout.php">Checkout</a></li>
            <li><a href="contact.php">Contact</a></li>
            <?php if (isset($_SESSION['user_id'])): ?>
                <li><a href="logout.php">Logout</a></li>
            <?php else: ?>
                <li><a href="auth.php">SignIn</a></li>
            <?php endif; ?>
        </ul>
    </nav>
    <div class="user-welcome">
        <?php if (isset($_SESSION['first_name'])): ?>
            <span>&nbsp;&nbsp;&nbsp;Welcome <?php echo htmlspecialchars($_SESSION['first_name']); ?></span>
        <?php endif; ?>
    </div>
</header>
<main>
    <div class="confirmation-container">
      <h2>Payment Confirmation</h2>

      <div class="confirmation-details">
        <section class="payment-info">
          <h3>Payment Details</h3>
          <p><strong>Cardholder Name:</strong> John Doe</p>
          <p><strong>Card Number:</strong> **** **** **** 1234</p>
          <p><strong>Expiry Date:</strong> 12/25</p>
          <p><strong>CVV:</strong> ***</p>
        </section>

        <section class="order-summary">
          <h3>Order Summary</h3>
          <p><strong>Subtotal:</strong> $100.00</p>
          <p><strong>Shipping:</strong> $5.00</p>
          <p><strong>Total:</strong> $105.00</p>
        </section>

        <section class="shipping-info">
          <h3>Shipping Information</h3>
          <p><strong>Name:</strong> John Doe</p>
          <p><strong>Address:</strong> 1234 Elm Street, Toronto, ON</p>
          <p><strong>Phone Number:</strong> 123-456-7890</p>
        </section>
      </div>

      <div class="confirmation-message">
        <h3>Thank you for your purchase!</h3>
        <p>Your payment has been successfully processed. You will receive an email confirmation shortly.</p>
        <a href="index.php" class="checkout-button">Go back to Home Page</a>
      </div>
    </div>
</main>

<footer>
  <div class="Footer">
    <div class="Footer-links">
      <h5>Quick Links</h5>
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="products.php">Products</a></li>
        <li><a href="about.php">About Us</a></li>
        <li><a href="contact.php">Contact</a></li>
      </ul>
    </div>
    <div class="footer-contact">
      <h5>Contact Us</h5>
      <p>123 Street, Hamilton, ON</p>
      <p>+1 123 000 7800</p>
    </div>
    
    <div class="footer-logo">
      <a href="index.php">
        <img src="imgs/logo.png" alt="Hamilton E-commerce Logo" class="logo-img">
      </a>
    </div>
    <div class="footer-social">
      <h5>Follow Us</h5>
      <a href="https://facebook.com" target=""><i class="fab fa-facebook"></i></a>
      <a href="https://twitter.com" target=""><i class="fab fa-twitter"></i></a>
      <a href="https://instagram.com" target=""><i class="fab fa-instagram"></i></a>
      <a href="https://linkedin.com" target=""><i class="fab fa-linkedin"></i></a>
    </div>
  </div>
</footer>

</body>
</html>
