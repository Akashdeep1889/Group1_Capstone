<?php
session_start();

// Database connection
$conn = new mysqli('localhost', 'root', '', 'store_db');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


// Add new product
if (isset($_POST['add_product'])) {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $image = $_FILES['image']['name'];
    
    // Upload image
    $target = "images/" . basename($image);
    if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
        $insert_query = "INSERT INTO products (title, description, price, image) VALUES ('$title', '$description', '$price', '$image')";
        $conn->query($insert_query);
    }
}

// Update product
if (isset($_POST['update_product'])) {
    $id = $_POST['id'];
    $title = $_POST['title'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $image = $_FILES['image']['name'];
    
    $update_query = "UPDATE products SET title='$title', description='$description', price='$price'";
    if ($image) {
        $target = "images/" . basename($image);
        if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
            $update_query .= ", image='$image'";
        }
    }
    $update_query .= " WHERE id=$id";
    $conn->query($update_query);
}

// Delete product
if (isset($_GET['delete_id'])) {
    $id = $_GET['delete_id'];
    $delete_query = "DELETE FROM products WHERE id=$id";
    $conn->query($delete_query);
}

// Fetch products for display
$products = $conn->query("SELECT * FROM products");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard</title>
  <link rel="stylesheet" href="css/styles.css">
  <link rel="stylesheet" href="css/mobile.css">
  <link rel="stylesheet" href="css/admin.css">
  <link rel="stylesheet" href="css/tablet.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<header>
    <div class="header">
        <div class="logo">
            <a href="index.php">
                <img src="imgs/logo.png" alt="Hamilton E-commerce Logo" class="logo-img">
            </a>
        </div>
        <h1>Hamilton E-commerce</h1>
        <div class="SearchBar">
            <input type="text" placeholder="Clothes">
            <button type="button">Search</button>
        </div>
    </div>
    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="products.php">Products</a></li>
            <li><a href="about.php">About Us</a></li>
            <li><a href="checkout.php">Checkout</a></li>
            <li><a href="contact.php">Contact</a></li>
            <?php if (isset($_SESSION['user_id'])): ?>
                <li><a href="logout.php">Logout</a></li>
            <?php else: ?>
                <li><a href="auth.php">SignIn</a></li>
            <?php endif; ?>
        </ul>
    </nav>
    <div class="user-welcome">
        <?php if (isset($_SESSION['first_name'])): ?>
            <span>&nbsp;&nbsp;&nbsp;Welcome <?php echo htmlspecialchars($_SESSION['first_name']); ?></span>
        <?php endif; ?>
    </div>
</header>
<body>
    <h1>Product Management</h1>
    <form method="POST" enctype="multipart/form-data">
    <h2>Add New Product</h2>
        <input type="text" name="title" placeholder="Title" required>
        <textarea name="description" placeholder="Description" required></textarea>
        <input type="number" name="price" placeholder="Price" step="0.01" required>
        <input type="file" name="image" required>
        <button type="submit" name="add_product">Add Product</button>
    </form>

    <div class="product-grid">

        <?php while ($product = $products->fetch_assoc()): ?>
            <div class="product-card">
                <img src="images/<?php echo $product['image']; ?>" 
                     alt="<?php echo htmlspecialchars($product['title']); ?>" 
                     class="product-image">
                <h3><?php echo htmlspecialchars($product['title']); ?></h3>
                <p><?php echo htmlspecialchars($product['description']); ?></p>
                <p class="price">$<?php echo number_format($product['price'], 2); ?></p>
                <div class="actions">
                <a href="admin.php?delete_id=<?php echo $product['id']; ?>" 
                       onclick="return confirm('Are you sure you want to delete this product?');" 
                       class="delete-link">Delete</a>
                   
                    <form method="POST" enctype="multipart/form-data" class="edit-form">
                        <input type="hidden" name="id" value="<?php echo $product['id']; ?>">
                        <input type="text" name="title" value="<?php echo htmlspecialchars($product['title']); ?>" required placeholder="Title">
                        <textarea name="description" required placeholder="Description"><?php echo htmlspecialchars($product['description']); ?></textarea>
                        <input type="number" name="price" value="<?php echo $product['price']; ?>" step="0.01" required placeholder="Price">
                        <input type="file" name="image" accept="image/*">
                        <button type="submit" name="update_product">Update</button>
                    </form>
                  
                    
                </div>
            </div>
        <?php endwhile; ?>
    </div>
   
</body>
<footer>
    <div class="Footer">
      <div class="Footer-links">
        <h5>Quick Links</h5>
        <ul>
          <li><a href="index.php">Home</a></li>
          <li><a href="products.php">Products</a></li>
          <li><a href="">About Us</a></li>
          <li><a href="">Contact</a></li>
        </ul>
      </div>
      <div class="footer-contact">
        <h5>Contact Us</h5>
        <p>123 Street, Hamilton, ON</p>
        <p>+1 123 000 7800</p>
      </div>
      <div class="footer-logo">
        <a href="index.php">
          <img src="imgs/logo.png" alt="Hamilton E-commerce Logo" class="logo-img">
        </a>
      </div>
      <div class="footer-social">
        <h5>Follow Us</h5>
        <a href="https://facebook.com" target=""><i class="fab fa-facebook"></i></a>
        <a href="https://twitter.com" target=""><i class="fab fa-twitter"></i></a>
        <a href="https://instagram.com" target=""><i class="fab fa-instagram"></i></a>
        <a href="https://linkedin.com" target=""><i class="fab fa-linkedin"></i></a>
      </div>
    </div>
</footer>
</html>

<?php $conn->close(); ?>
