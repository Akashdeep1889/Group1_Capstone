<?php
session_start();
$conn = new mysqli('localhost', 'root', '', 'store_db');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch random images from the products table
$images_sql = "SELECT image FROM products ORDER BY RAND() LIMIT 40"; 
$images_result = $conn->query($images_sql);

$images = [];
if ($images_result->num_rows > 0) {
    while ($image = $images_result->fetch_assoc()) {
        $images[] = htmlspecialchars($image['image']);
    }
} else {
    echo "<p>No images available for the slider.</p>";
}

// Initialize session variable for index
if (!isset($_SESSION['current_index'])) {
    $_SESSION['current_index'] = 0; 
}

$current_images_1 = [];
$current_images_2 = [];

// Get images for the first slider
for ($i = 0; $i < 6; $i++) {
    if (isset($images[$_SESSION['current_index']])) {
        $current_images_1[] = $images[$_SESSION['current_index']];
    }
    $_SESSION['current_index'] = ($_SESSION['current_index'] + 1) % count($images); 
}

// Get images for the second slider
for ($i = 0; $i < 6; $i++) {
    if (isset($images[$_SESSION['current_index']])) {
        $current_images_2[] = $images[$_SESSION['current_index']];
    }
    $_SESSION['current_index'] = ($_SESSION['current_index'] + 1) % count($images); 
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>HomePage- Hamilton e-commerce</title>
  <link rel="stylesheet" href="css/styles.css">
  <link rel="stylesheet" href="css/mobile.css">
  <link rel="stylesheet" href="css/tablet.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">


</head>
</head>
<body>


<header>
    <div class="header">
        <div class="logo">
            <a href="index.php">
                <img src="imgs/logo.png" alt="Hamilton E-commerce Logo" class="logo-img">
            </a>
        </div>

        <h1>Hamilton E-commerce</h1>

        <div class="SearchBar">
            <input type="text" placeholder="Clothes">
            <button type="button">Search</button>
        </div>
    </div>

    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="products.php">Products</a></li>
            <li><a href="about.php">About Us</a></li>
            <li><a href="checkout.php">Checkout</a></li>
            <li><a href="contact.php">Contact</a></li>
            <?php if (isset($_SESSION['user_id'])): ?>
                <li><a href="logout.php">Logout</a></li>
            <?php else: ?>
                <li><a href="auth.php">SignIn</a></li>
            <?php endif; ?>
        </ul>
    </nav>

    <div class="user-welcome">
        <?php if (isset($_SESSION['first_name'])): ?>
            <span>&nbsp;&nbsp;&nbsp;Welcome <?php echo htmlspecialchars($_SESSION['first_name']); ?></span>
        <?php endif; ?>

        <!-- Cart Icon -->
        <div class="cart-icon">
            <a href="cart.php" style="text-decoration: none; color: inherit;">
                <i class="fas fa-shopping-cart"></i>
                <?php
                // Fetch the total number of items in the cart
                $user_id = $_SESSION['user_id'] ?? 0;
                $cart_count = 0;

                if ($user_id) {
                    $cart_count_sql = "SELECT SUM(quantity) as total_items FROM cart WHERE user_id = ?";
                    $cart_count_stmt = $conn->prepare($cart_count_sql);
                    $cart_count_stmt->bind_param("i", $user_id);
                    $cart_count_stmt->execute();
                    $cart_count_result = $cart_count_stmt->get_result();
                    $cart_data = $cart_count_result->fetch_assoc();
                    $cart_count = $cart_data['total_items'] ?? 0;
                }
                ?>
                <span class="cart-count">(<?php echo $cart_count; ?>)</span>
            </a>
        </div>
    </div>
</header>



  <div class="hero-image"></div>
  <div class="hero-text">
    <h2>Shop Quality Products at Unbeatable Prices!</h2>
  </div>
  <main>
  <section class="featured-products">
    <h2 class="heading-center">Latest Products </h2>
    <div class="items-container">
        <?php
        // Fetch random products without any filters
        $sales_sql = "SELECT * FROM products ORDER BY RAND() LIMIT 10"; 
        $sales_result = $conn->query($sales_sql);
        
        if ($sales_result->num_rows > 0) {
            while ($product = $sales_result->fetch_assoc()): ?>
                <div class="item-card">
                    <img src="images/<?php echo $product['image']; ?>" class="item-image" alt="<?php echo htmlspecialchars($product['title']); ?>">
                    <div class="item-info">
                        <h5 class="item-title"><?php echo htmlspecialchars($product['title']); ?></h5>
                        <p class="item-price">Price: $<?php echo number_format($product['price'], 2); ?></p>
                        <a href="product_detail.php?id=<?php echo $product['id']; ?>" class="btn-view">View Details</a>
                    </div>
                </div>
        <?php endwhile; 
        } else {
            echo "<p>No products available.</p>";
        }
        ?>
    </div>
</section>
<section class="slider-section">
<div class="text-content">
         
        </div>
        <div class="sliders">
            <!-- First Slider -->
            <div class="slider">
            
                <div class="slider-grid">
                    <?php foreach ($current_images_1 as $image): ?>
                        <div class="slide">
                            <?php if ($image): ?>
                                <img src="images/<?php echo $image; ?>" alt="Slider Image">
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <!-- Second Slider -->
            <div class="slider">
               
                <div class="slider-grid">
                    <?php foreach ($current_images_2 as $image): ?>
                        <div class="slide">
                            <?php if ($image): ?>
                                <img src="images/<?php echo $image; ?>" alt="Slider Image">
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
</section>



    
  </main>

  <footer>
    <div class="Footer">
      <div class="Footer-links">
        <h5>Quick Links</h5>
        <ul>
          <li><a href="index.php">Home</a></li>
          <li><a href="products.php">Products</a></li>
          <li><a href="">About Us</a></li>
          <li><a href="">Contact</a></li>
       
        </ul>
      </div>
      <div class="footer-contact">
        <h5>Contact Us</h5>
        <p>123 Street, Hamilton, ON</p>
        <p>+1 123 000 7800</p>
      </div>
      
      
      <div class="footer-logo">
        <a href="index.php">
          <img src="imgs/logo.png" alt="Hamilton E-commerce Logo" class="logo-img">
        </a>
      </div>
      <div class="footer-social">
        <h5>Follow Us</h5>
        <a href="https://facebook.com" target=""><i class="fab fa-facebook"></i></a>
        <a href="https://twitter.com" target=""><i class="fab fa-twitter"></i></a>
        <a href="https://instagram.com" target=""><i class="fab fa-instagram"></i></a>
        <a href="https://linkedin.com" target=""><i class="fab fa-linkedin"></i></a>
      </div>
    </div>
  </footer>
  

</body>
</html>
