<?php
session_start();

// Database connection
$conn = new mysqli('localhost', 'root', '', 'store_db');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: auth.php"); // Redirect to login if not logged in
    exit();
}

// Add to cart functionality
if (isset($_GET['action']) && $_GET['action'] == 'add' && isset($_GET['id'])) {
    $user_id = $_SESSION['user_id'];
    $product_id = intval($_GET['id']);

    // Check if the product already exists in the cart
    $check_sql = "SELECT * FROM cart WHERE user_id = ? AND product_id = ?";
    $stmt = $conn->prepare($check_sql);
    $stmt->bind_param("ii", $user_id, $product_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // If the product already exists, update the quantity
        $update_sql = "UPDATE cart SET quantity = quantity + 1 WHERE user_id = ? AND product_id = ?";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param("ii", $user_id, $product_id);
        $update_stmt->execute();
    } else {
        // If the product does not exist, insert it into the cart
        $insert_sql = "INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, 1)";
        $insert_stmt = $conn->prepare($insert_sql);
        $insert_stmt->bind_param("ii", $user_id, $product_id);
        $insert_stmt->execute();
    }

    // Redirect back to products page after adding to cart
    header("Location: products.php");
    exit();
}

// Update cart functionality
if (isset($_POST['update_cart'])) {
    foreach ($_POST['quantity'] as $item_id => $quantity) {
        if ($quantity <= 0) {
            // Remove item from cart if quantity is zero or negative
            $delete_sql = "DELETE FROM cart WHERE id = ?";
            $delete_stmt = $conn->prepare($delete_sql);
            $delete_stmt->bind_param("i", $item_id);
            $delete_stmt->execute();
        } else {
            // Update item quantity in cart
            $update_sql = "UPDATE cart SET quantity = ? WHERE id = ?";
            $update_stmt = $conn->prepare($update_sql);
            $update_stmt->bind_param("ii", $quantity, $item_id);
            $update_stmt->execute();
        }
    }

    // Redirect back to cart page after updating
    header("Location: cart.php");
    exit();
}

// Clear cart functionality
if (isset($_POST['clear_cart'])) {
    $user_id = $_SESSION['user_id'];

    // Delete all items from the cart for the current user
    $clear_cart_sql = "DELETE FROM cart WHERE user_id = ?";
    $clear_cart_stmt = $conn->prepare($clear_cart_sql);
    $clear_cart_stmt->bind_param("i", $user_id);
    $clear_cart_stmt->execute();

    // Redirect back to cart page after clearing
    header("Location: cart.php");
    exit();
}

// View cart functionality
$cart_items = [];
$total_price = 0;

$cart_sql = "SELECT c.id, p.title, p.price, c.quantity 
             FROM cart c 
             JOIN products p ON c.product_id = p.id 
             WHERE c.user_id = ?";
$cart_stmt = $conn->prepare($cart_sql);
$cart_stmt->bind_param("i", $_SESSION['user_id']);
$cart_stmt->execute();
$cart_result = $cart_stmt->get_result();

while ($row = $cart_result->fetch_assoc()) {
    $cart_items[] = $row;
    $total_price += $row['price'] * $row['quantity'];
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/cart.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
<header>
    <div class="header">
        <div class="logo">
            <a href="index.php">
                <img src="imgs/logo.png" alt="Hamilton E-commerce Logo" class="logo-img">
            </a>
        </div>

        <h1>Hamilton E-commerce</h1>

        <div class="SearchBar">
            <input type="text" placeholder="Clothes">
            <button type="button">Search</button>
        </div>
    </div>
    
    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="products.php">Products</a></li>
            <li><a href="about.php">About Us</a></li>
            <li><a href="checkout.php">Checkout</a></li>
            <li><a href="contact.php">Contact</a></li>
            <?php if (isset($_SESSION['user_id'])): ?>
                <li><a href="logout.php">Logout</a></li>
            <?php else: ?>
                <li><a href="auth.php">SignIn</a></li>
            <?php endif; ?>
        </ul>
    </nav>

    <div class="user-welcome">
        <?php if (isset($_SESSION['first_name'])): ?>
            <span>&nbsp;&nbsp;&nbsp;Welcome <?php echo htmlspecialchars($_SESSION['first_name']); ?></span>
        <?php endif; ?>
            <!-- Cart Icon -->
        <div class="cart-icon">
            <a href="cart.php" style="text-decoration: none; color: inherit;">
                <i class="fas fa-shopping-cart"></i>
                <?php
                // Fetch the total number of items in the cart
                $user_id = $_SESSION['user_id'] ?? 0;
                $cart_count = 0;

                if ($user_id) {
                    $cart_count_sql = "SELECT SUM(quantity) as total_items FROM cart WHERE user_id = ?";
                    $cart_count_stmt = $conn->prepare($cart_count_sql);
                    $cart_count_stmt->bind_param("i", $user_id);
                    $cart_count_stmt->execute();
                    $cart_count_result = $cart_count_stmt->get_result();
                    $cart_data = $cart_count_result->fetch_assoc();
                    $cart_count = $cart_data['total_items'] ?? 0;
                }
                ?>
                <span class="cart-count">(<?php echo $cart_count; ?>)</span>
            </a>
        </div>
        
    </div>
</header>

<div class="container">
    <h2>Items in Your Cart</h2>
    <?php if (empty($cart_items)): ?>
        <p>Your cart is empty. Add some products!</p>
    <?php else: ?>
        <form action="cart.php" method="post">
            <table>
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($cart_items as $item): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($item['title']); ?></td>
                            <td>$<?php echo number_format($item['price'], 2); ?></td>
                            <td>
                                <input type="number" name="quantity[<?php echo $item['id']; ?>]" value="<?php echo $item['quantity']; ?>" min="0">
                            </td>
                            <td>$<?php echo number_format($item['price'] * $item['quantity'], 2); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="3"><strong>Total:</strong></td>
                        <td>$<?php echo number_format($total_price, 2); ?></td>
                    </tr>
                </tfoot>
            </table>
            <button type="submit" name="update_cart" class="update-button">Update Cart</button>
            <button type="submit" name="clear_cart" class="clear-button" style="background-color: red; color: white;">Clear Cart</button>
        </form>
        <a href="checkout.php" class="checkout-button">Proceed to Checkout</a>
    <?php endif; ?>
</div>

<footer>
    <div class="Footer">
        <div class="Footer-links">
            <h5>Quick Links</h5>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="products.php">Products</a></li>
                <li><a href="about.php">About Us</a></li>
                <li><a href="">Contact</a></li>
            </ul>
        </div>
        <div class="footer-contact">
            <h5>Contact Us</h5>
            <p>123 Street, Hamilton, ON</p>
            <p>+1 123 000 7800</p>
        </div>
        <div class="footer-logo">
            <a href="index.php">
                <img src="imgs/logo.png" alt="Hamilton E-commerce Logo" class="logo-img">
            </a>
        </div>
        <div class="footer-social">
            <h5>Follow Us</h5>
            <a href="https://facebook.com" target="_blank"><i class="fab fa-facebook"></i></a>
            <a href="https://twitter.com" target="_blank"><i class="fab fa-twitter"></i></a>
            <a href="https://instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
            <a href="https://linkedin.com" target="_blank"><i class="fab fa-linkedin"></i></a>
        </div>
    </div>
</footer>

</body>
</html>

<?php
$conn->close();
?>
