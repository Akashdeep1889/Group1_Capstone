<?php
session_start();

// Database connection
$conn = new mysqli('localhost', 'root', '', 'store_db');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the product ID is set in the URL
if (isset($_GET['id'])) {
    $product_id = intval($_GET['id']);
    
    // Fetch product details from the database
    $sql = "SELECT title, description, price, image FROM products WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    // Check if the product exists
    if ($result->num_rows > 0) {
        $product = $result->fetch_assoc();
    } else {
        die("Product not found.");
    }
} else {
    die("Invalid product ID.");
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($product['title']); ?> - Product Details</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/product.css">
</head>
<body>

<header>
    <div class="header">
        <div class="logo">
            <a href="index.php">
                <img src="imgs/logo.png" alt="Hamilton E-commerce Logo" class="logo-img">
            </a>
        </div>
        <h1>Hamilton E-commerce</h1>
        <div class="SearchBar">
            <input type="text" placeholder="Search products...">
            <button type="button">Search</button>
        </div>
    </div>

    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="products.php">Products</a></li>
            <li><a href="about.php">About Us</a></li>
            <li><a href="checkout.php">Checkout</a></li>
            <li><a href="contact.php">Contact</a></li>
            <?php if (isset($_SESSION['user_id'])): ?>
                <li><a href="logout.php">Logout</a></li>
            <?php else: ?>
                <li><a href="auth.php">Sign In</a></li>
            <?php endif; ?>
        </ul>
    </nav>
    <div class="user-welcome">
        <?php if (isset($_SESSION['first_name'])): ?>
            <span>&nbsp;&nbsp;&nbsp;Welcome <?php echo htmlspecialchars($_SESSION['first_name']); ?></span>
        <?php endif; ?>
    </div>
</header>

<div class="container">
    <h2><?php echo htmlspecialchars($product['title']); ?></h2>
    <div class="product-detail">
        <img src="images/<?php echo htmlspecialchars($product['image']); ?>" alt="<?php echo htmlspecialchars($product['title']); ?>" class="product img">
        <div class="product-info">
            <p><strong>Price:</strong> $<?php echo number_format($product['price'], 2); ?></p>
            <p><strong>Description:</strong></p>
            <p><?php echo nl2br(htmlspecialchars($product['description'])); ?></p>
           
        </div>
    </div>
    <a href="products.php" class="continue-shopping-button">Continue Shopping</a>
    <a href="cart.php" class="cart-button">Go to Cart</a>
</div>

<footer>
    <div class="Footer">
        <div class="Footer-links">
            <h5>Quick Links</h5>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="products.php">Products</a></li>
                <li><a href="">About Us</a></li>
                <li><a href="">Contact</a></li>
            </ul>
        </div>
        <div class="footer-contact">
            <h5>Contact Us</h5>
            <p>123 Street, Hamilton, ON</p>
            <p>+1 123 000 7800</p>
        </div>
        <div class="footer-logo">
            <a href="index.html">
                <img src="imgs/logo.png" alt="Hamilton E-commerce Logo" class="logo-img">
            </a>
        </div>
        <div class="footer-social">
            <h5>Follow Us</h5>
            <a href="https://facebook.com" target=""><i class="fab fa-facebook"></i></a>
            <a href="https://twitter.com" target=""><i class="fab fa-twitter"></i></a>
            <a href="https://instagram.com" target=""><i class="fab fa-instagram"></i></a>
            <a href="https://linkedin.com" target=""><i class="fab fa-linkedin"></i></a>
        </div>
    </div>
</footer>
  
</body>
</html>

<?php
$conn->close();
?>
