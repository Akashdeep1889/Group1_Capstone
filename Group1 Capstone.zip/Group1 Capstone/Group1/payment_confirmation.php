<?php
session_start();
$conn = new mysqli('localhost', 'root', '', 'store_db');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['user_id'])) {
    header("Location: auth.php"); // Redirect to sign-in if user is not logged in
    exit;
}

// Fetch the order details based on the user session
$user_id = $_SESSION['user_id'];
$query = "SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC LIMIT 1"; // Get the most recent order
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $order = $result->fetch_assoc();
} else {
    // Redirect if no order is found
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Payment Confirmation - Hamilton E-commerce</title>
  <link rel="stylesheet" href="css/styles.css">
  <link rel="stylesheet" href="css/mobile.css">
  <link rel="stylesheet" href="css/tablet.css">
  <link rel="stylesheet" href="css/signin.css">
  <link rel="stylesheet" href="css/checkout.css">
  <link rel="stylesheet" href="css/contact.css">
  <link rel="stylesheet" href="css/payment.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
  
<header>
    <div class="header">
        <div class="logo">
            <a href="index.php">
                <img src="imgs/logo.png" alt="Hamilton E-commerce Logo" class="logo-img">
            </a>
        </div>
        <h1>Hamilton E-commerce</h1>
        <div class="SearchBar">
            <input type="text" placeholder="Clothes">
            <button type="button">Search</button>
        </div>
    </div>

    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="products.php">Products</a></li>
            <li><a href="about.php">About Us</a></li>
            <li><a href="checkout.php">Checkout</a></li>
            <li><a href="contact.php">Contact</a></li>
            <?php if (isset($_SESSION['user_id'])): ?>
                <li><a href="logout.php">Logout</a></li>
            <?php else: ?>
                <li><a href="auth.php">SignIn</a></li>
            <?php endif; ?>
        </ul>
    </nav>
    <div class="user-welcome">
        <?php if (isset($_SESSION['first_name'])): ?>
            <span>&nbsp;&nbsp;&nbsp;Welcome <?php echo htmlspecialchars($_SESSION['first_name']); ?></span>
        <?php endif; ?>
    </div>
</header>

<main>
    <div class="confirmation-container">
        <h2>Payment Confirmation</h2>

        <div class="confirmation-details">
            <section class="payment-info">
                <h3>Payment Details</h3>
                <p><strong>Cardholder Name:</strong> <?php echo htmlspecialchars($order['cardholder_name']); ?></p>
                <p><strong>Card Number:</strong> **** **** **** <?php echo substr($order['card_number'], -4); ?></p>
                <p><strong>Expiry Date:</strong> <?php echo date('m/y', strtotime($order['expiry_date'])); ?></p>
                <p><strong>CVV:</strong> ***</p>
            </section>

            <section class="order-summary">
                <h3>Order Summary</h3>
                <p><strong>Subtotal:</strong> $<?php echo number_format($order['subtotal'], 2); ?></p>
                <p><strong>Shipping:</strong> $<?php echo number_format($order['shipping'], 2); ?></p>
                <p><strong>Total:</strong> $<?php echo number_format($order['total'], 2); ?></p>
            </section>

            <section class="shipping-info">
                <h3>Shipping Information</h3>
                <p><strong>Name:</strong> <?php echo htmlspecialchars($order['fullname'])?></p>
                <p><strong>Address:</strong> <?php echo htmlspecialchars($order['shipping_address']) . ', ' . htmlspecialchars($order['shipping_city']) . ', ' . htmlspecialchars($order['shipping_state']) . ', ' . htmlspecialchars($order['shipping_zip']); ?></p>
                <p><strong>Phone Number:</strong> <?php echo htmlspecialchars($order['phone_number']); ?></p>
            </section>
        </div>

        <div class="confirmation-message">
            <h3>Thank you for your purchase!</h3>
            <p>Your payment has been successfully processed. You will receive an email confirmation shortly.</p>
            
            <a href="generate_invoice.php" class=" checkout-button">Download Invoice</a>

            <a href="index.php" class="checkout-button">Go back to Home Page</a>
        </div>
    </div>
</main>

<footer>
    <div class="Footer">
        <div class="Footer-links">
            <h5>Quick Links</h5>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="products.php">Products</a></li>
                <li><a href="about.php">About Us</a></li>
                <li><a href="contact.php">Contact</a></li>
            </ul>
        </div>
        <div class="footer-contact">
            <h5>Contact Us</h5>
            <p>123 Street, Hamilton, ON</p>
            <p>+1 123 000 7800</p>
        </div>
        <div class="footer-logo">
            <a href="index.php">
                <img src="imgs/logo.png" alt="Hamilton E-commerce Logo" class="logo-img">
            </a>
        </div>
        <div class="footer-social">
            <h5>Follow Us</h5>
            <a href="https://facebook.com" target=""><i class="fab fa-facebook"></i></a>
            <a href="https://twitter.com" target=""><i class="fab fa-twitter"></i></a>
            <a href="https://instagram.com" target=""><i class="fab fa-instagram"></i></a>
            <a href="https://linkedin.com" target=""><i class="fab fa-linkedin"></i></a>
        </div>
    </div>
</footer>

</body>
</html>
