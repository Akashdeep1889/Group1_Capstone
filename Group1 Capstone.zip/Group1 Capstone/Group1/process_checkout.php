<?php
session_start();
$conn = new mysqli('localhost', 'root', '', 'store_db');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['user_id'])) {
    header("Location: auth.php");
    exit();
}

// Collect form data from POST request
$fullname = mysqli_real_escape_string($conn, $_POST['fullname']);
$email = mysqli_real_escape_string($conn, $_POST['email']);
$address = mysqli_real_escape_string($conn, $_POST['address']);
$city = mysqli_real_escape_string($conn, $_POST['city']);
$postal_code = mysqli_real_escape_string($conn, $_POST['postalCode']);
$phone = mysqli_real_escape_string($conn, $_POST['phone']);
$cardholder_name = mysqli_real_escape_string($conn, $_POST['cardName']);
$card_number = mysqli_real_escape_string($conn, $_POST['cardNumber']);
$expiry_date = mysqli_real_escape_string($conn, $_POST['expiryDate']);
$cvv = mysqli_real_escape_string($conn, $_POST['cvv']);
$shipping_address = $address;
$shipping_city = $city;
$shipping_zip = $postal_code;
$shipping_state = '';  // Assuming no state info is provided
$phone_number = $phone;

// Calculate subtotal, shipping, and total
$subtotal = 0;
$shipping = 10.00; // Fixed shipping cost, can be dynamic based on location
$total = 0;

$cart_items = [];
$cart_sql = "SELECT c.id, p.price, c.quantity 
             FROM cart c 
             JOIN products p ON c.product_id = p.id 
             WHERE c.user_id = ?";
$cart_stmt = $conn->prepare($cart_sql);
$cart_stmt->bind_param("i", $_SESSION['user_id']);
$cart_stmt->execute();
$cart_result = $cart_stmt->get_result();

while ($row = $cart_result->fetch_assoc()) {
    $cart_items[] = $row;
    $subtotal += $row['price'] * $row['quantity'];
}

$total = $subtotal + $shipping;

$order_sql = "INSERT INTO orders (user_id, fullname, cardholder_name, card_number, expiry_date, cvv, subtotal, shipping, total, shipping_address, shipping_city, shipping_state, shipping_zip, phone_number)
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

$order_stmt = $conn->prepare($order_sql);
$order_stmt->bind_param("issssdddssssss", 
    $_SESSION['user_id'],        // INT
    $fullname,                   // STRING
    $cardholder_name,            // STRING
    $card_number,                // STRING
    $expiry_date,                // STRING (DATE stored as a string in PHP)
    $cvv,                        // STRING
    $subtotal,                   // DECIMAL
    $shipping,                   // DECIMAL
    $total,                      // DECIMAL
    $shipping_address,           // STRING
    $shipping_city,              // STRING
    $shipping_state,             // STRING
    $shipping_zip,               // STRING
    $phone_number                // STRING
);

if ($order_stmt->execute()) {
    // Order successfully placed, redirect to the payment confirmation page
    header("Location: payment_confirmation.php");
    exit();
} else {
    // Handle any errors
    echo "Error placing order: " . $conn->error;
}

$conn->close();
?>