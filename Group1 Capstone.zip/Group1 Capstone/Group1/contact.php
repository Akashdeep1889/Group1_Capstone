<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Contact Us - Hamilton E-commerce</title>
  <link rel="stylesheet" href="css/styles.css">
  <link rel="stylesheet" href="css/mobile.css">
  <link rel="stylesheet" href="css/tablet.css">
  <link rel="stylesheet" href="css/signin.css">
  <link rel="stylesheet" href="css/checkout.css">
  <link rel="stylesheet" href="css/contact.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

  
  <script>
    function validateForm() {
      var name = document.getElementById("name").value;
      var email = document.getElementById("email").value;
      var subject = document.getElementById("subject").value;
      var message = document.getElementById("message").value;
      
      if (name == "" || email == "" || subject == "" || message == "") {
        alert("All fields must be filled out");
        return false;
      }
      
      var emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
      if (!emailPattern.test(email)) {
        alert("Please enter a valid email address");
        return false;
      }
      
      return true;
    }
  </script>
</head>
<body>

<?php
session_start();
?>

<header>
    <div class="header">
        <div class="logo">
            <a href="index.php">
                <img src="imgs/logo.png" alt="Hamilton E-commerce Logo" class="logo-img">
            </a>
        </div>
        <h1>Hamilton E-commerce</h1>
        <div class="SearchBar">
            <input type="text" placeholder="Clothes">
            <button type="button">Search</button>
        </div>
    </div>

    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="products.php">Products</a></li>
            <li><a href="checkout.php">Checkout</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li><a href="about.php">About Us</a></li>
            <?php if (isset($_SESSION['user_id'])): ?>
                <li><a href="logout.php">Logout</a></li>
            <?php else: ?>
                <li><a href="auth.php">SignIn</a></li>
            <?php endif; ?>
        </ul>
    </nav>
    <div class="user-welcome">
            <?php if (isset($_SESSION['first_name'])): ?>
                <span>&nbsp;&nbsp;&nbsp;Welcome <?php echo htmlspecialchars($_SESSION['first_name']); ?></span>
            <?php endif; ?>
        </div>
</header>

<main>
    <div class="contact-container">
        <section class="gallery">
            <h3>Our Store Gallery</h3>
            <div class="gallery-images">
                <img src="images/store2.jpg" alt="Store image 1">
                <img src="images/store5.jpg" alt="Store image 2">
            </div>
        </section>

        <section class="contact-form">
            <h2>Get in Touch</h2>
            <form action="process_contact.php" method="POST" onsubmit="return validateForm()">
                <label for="name">Name</label>
                <input type="text" id="name" name="name" required>

                <label for="email">Email</label>
                <input type="email" id="email" name="email" required>

                <label for="subject">Subject</label>
                <input type="text" id="subject" name="subject" required>

                <label for="message">Message</label>
                <textarea id="message" name="message" rows="6" required></textarea>

                <button type="submit" class="submit-button">Send Message</button>
            </form>
        </section>

        <section class="contact-details">
            <h3>Our Contact Details</h3>
            <p>Address: 123 Street, Hamilton, ON</p>
            <p>Phone: +1 123 000 7800</p>
            <p>Email: support@hamiltonecommerce.com</p>
        </section>

        <section class="reviews">
            <h3>Customer Reviews</h3>
            <div class="review">
                <p>“Fantastic customer service and quality products. Highly recommend!”</p>
                <span>- Sarah D.</span>
            </div>
            <div class="review">
                <p>“Amazing experience! The staff was very helpful.”</p>
                <span>- Alex W.</span>
            </div>
        </section>

        <section class="map">
            <h3>Find Us Here</h3>
            <div class="map-container">
                <iframe 
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2886.279563270335!2d-79.86609138452214!3d43.25572037913778!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x882c9b9b1b5d9aab%3A0x5e77d5b22a5c8c58!2sHamilton%2C%20ON%2C%20Canada!5e0!3m2!1sen!2sus!4v1636483084390!5m2!1sen!2sus"
                    width="100%" height="300" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
            </div>
        </section>
    </div>
</main>

<footer>
    <div class="Footer">
        <div class="Footer-links">
            <h5>Quick Links</h5>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="products.php">Products</a></li>
                <li><a href="about.php">About Us</a></li>
                <li><a href="contact.php">Contact</a></li>
            </ul>
        </div>
        <div class="footer-contact">
            <h5>Contact Us</h5>
            <p>123 Street, Hamilton, ON</p>
            <p>+1 123 000 7800</p>
        </div>
        <div class="footer-social">
            <h5>Follow Us</h5>
            <a href="https://facebook.com" target=""><i class="fab fa-facebook"></i></a>
            <a href="https://twitter.com" target=""><i class="fab fa-twitter"></i></a>
            <a href="https://instagram.com" target=""><i class="fab fa-instagram"></i></a>
            <a href="https://linkedin.com" target=""><i class="fab fa-linkedin"></i></a>
        </div>
    </div>
</footer>

</body>
</html>
