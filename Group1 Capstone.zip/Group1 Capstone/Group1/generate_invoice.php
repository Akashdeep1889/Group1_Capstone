<?php
require('fpdf184/fpdf.php'); // Adjust path if needed

session_start();
$conn = new mysqli('localhost', 'root', '', 'store_db');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['user_id'])) {
    header("Location: auth.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$query = "SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC LIMIT 1";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $order = $result->fetch_assoc();
} else {
    header("Location: index.php");
    exit;
}

// Create PDF
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 16);

// Title
$pdf->SetTextColor(0, 102, 204); // Blue color for the title
$pdf->Cell(200, 10, 'Invoice', 0, 1, 'C');
$pdf->Cell(200, 10, 'Hamilton-Ecommerce', 0, 1, 'C');
$pdf->Ln(5);

// Add Order Details
$pdf->SetFont('Arial', 'B', 12);
$pdf->SetTextColor(0, 0, 0); // Black color for text
$pdf->Cell(0, 10, 'Order Details', 0, 1, 'L');
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(0, 10, 'Name: ' . htmlspecialchars($order['fullname']), 0, 1, 'L');
$pdf->Cell(0, 10, 'Address: ' . htmlspecialchars($order['shipping_address']) . ', ' . htmlspecialchars($order['shipping_city']) . ', ' . htmlspecialchars($order['shipping_state']) . ', ' . htmlspecialchars($order['shipping_zip']), 0, 1, 'L');
$pdf->Cell(0, 10, 'Phone: ' . htmlspecialchars($order['phone_number']), 0, 1, 'L');
$pdf->Ln(5);

// Add Payment Details
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 10, 'Payment Details', 0, 1, 'L');
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(0, 10, 'Cardholder Name: ' . htmlspecialchars($order['cardholder_name']), 0, 1, 'L');
$pdf->Cell(0, 10, 'Card Number: **** **** **** ' . substr($order['card_number'], -4), 0, 1, 'L');
$pdf->Cell(0, 10, 'Expiry Date: ' . date('m/y', strtotime($order['expiry_date'])), 0, 1, 'L');
$pdf->Cell(0, 10, 'CVV: ***', 0, 1, 'L');
$pdf->Ln(5);

// Add Order Summary
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 10, 'Order Summary', 0, 1, 'L');
$pdf->SetFont('Arial', '', 12);

// Use a table for order summary
$pdf->SetFillColor(230, 230, 230); // Light gray background for the table
$pdf->Cell(100, 10, 'Subtotal:', 1, 0, 'L', true);
$pdf->Cell(0, 10, '$' . number_format($order['subtotal'], 2), 1, 1, 'R');
$pdf->Cell(100, 10, 'Shipping:', 1, 0, 'L', true);
$pdf->Cell(0, 10, '$' . number_format($order['shipping'], 2), 1, 1, 'R');
$pdf->Cell(100, 10, 'Total:', 1, 0, 'L', true);
$pdf->Cell(0, 10, '$' . number_format($order['total'], 2), 1, 1, 'R');
$pdf->Ln(10);

// Footer Section
$pdf->SetFont('Arial', 'I', 10);
$pdf->Cell(0, 10, 'Thank you for your purchase! Hamilton-Ecommerce', 0, 1, 'C');

// Output PDF
$pdf->Output();
?>
