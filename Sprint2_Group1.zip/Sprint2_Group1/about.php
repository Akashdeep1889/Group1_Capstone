<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/about.css">
</head>
<body>
<header>
    <div class="header">
        <div class="logo">
            <a href="index.php">
                <img src="imgs/logo.png" alt="Hamilton E-commerce Logo" class="logo-img">
            </a>
        </div>
        <h1>Hamilton E-commerce</h1>
        <div class="SearchBar">
            <input type="text" placeholder="Search...">
            <button type="button">Search</button>
        </div>
    </div>

    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="products.php">Products</a></li>
            <li><a href="about.php">About Us</a></li>
            <li><a href="checkout.php">Checkout</a></li>
            <li><a href="contact.php">Contact</a></li>
            <?php if (isset($_SESSION['user_id'])): ?>
                <li><a href="logout.php">Logout</a></li>
            <?php else: ?>
                <li><a href="auth.php">Sign In</a></li>
            <?php endif; ?>
        </ul>
    </nav>
</header>

<div class="about-container">
    <section class="about-banner">
        <h2>About Us</h2>
        <p>Your trusted source for quality products and customer satisfaction.</p>
    </section>

    <section class="our-story">
        <h3>Our Story</h3>
        <p>
            Founded in 2020, Hamilton E-commerce began with a simple mission: to provide quality products at fair prices, all while ensuring an exceptional shopping experience. What started as a small venture has now grown into a trusted eCommerce platform serving customers around the globe.
        </p>
        <p>
            Our journey has been one of passion, dedication, and commitment to customer satisfaction. From humble beginnings, we have expanded our offerings and continually strive to bring new and innovative products to our customers.
        </p>
    </section>

    <section class="core-values">
        <h3>Our Core Values</h3>
        <div class="value-grid">
            <div class="value-card">
                <h4>Quality</h4>
                <p>We ensure each product meets high standards of quality to provide our customers with value and satisfaction.</p>
            </div>
            <div class="value-card">
                <h4>Integrity</h4>
                <p>Our team operates with honesty and transparency, building trust in all that we do.</p>
            </div>
            <div class="value-card">
                <h4>Customer Focus</h4>
                <p>Your satisfaction is our top priority. We’re here to meet your needs and exceed your expectations.</p>
            </div>
            <div class="value-card">
                <h4>Innovation</h4>
                <p>We constantly evolve to bring new and exciting products to your fingertips.</p>
            </div>
        </div>
    </section>

    <section class="meet-the-team">
        <h3>Meet the Team</h3>
        <div class="team-grid">
            <div class="team-member">
                <img src="imgs/team1.jpg" alt="Team Member 1">
                <h4>Jane Doe</h4>
                <p>CEO & Founder</p>
            </div>
            <div class="team-member">
                <img src="imgs/team2.jpg" alt="Team Member 2">
                <h4>John Smith</h4>
                <p>Head of Operations</p>
            </div>
            <div class="team-member">
                <img src="imgs/team3.jpg" alt="Team Member 3">
                <h4>Emily Johnson</h4>
                <p>Lead Designer</p>
            </div>
        </div>
    </section>
</div>

<footer>
    <div class="Footer">
        <div class="Footer-links">
            <h5>Quick Links</h5>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="products.php">Products</a></li>
                <li><a href="about.php">About Us</a></li>
                <li><a href="contact.php">Contact</a></li>
            </ul>
        </div>
        <div class="footer-contact">
            <h5>Contact Us</h5>
            <p>123 Street, Hamilton, ON</p>
            <p>+1 123 000 7800</p>
        </div>
        <div class="footer-logo">
            <a href="index.php">
                <img src="imgs/logo.png" alt="Hamilton E-commerce Logo" class="logo-img">
            </a>
        </div>
        <div class="footer-social">
            <h5>Follow Us</h5>
            <a href="https://facebook.com" target="_blank"><i class="fab fa-facebook"></i></a>
            <a href="https://twitter.com" target="_blank"><i class="fab fa-twitter"></i></a>
            <a href="https://instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
            <a href="https://linkedin.com" target="_blank"><i class="fab fa-linkedin"></i></a>
        </div>
    </div>
</footer>

</body>
</html>
