<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Checkout - Hamilton E-commerce</title>
  <link rel="stylesheet" href="css/styles.css">
  <link rel="stylesheet" href="css/mobile.css">
  <link rel="stylesheet" href="css/tablet.css">
  <link rel="stylesheet" href="css/signin.css">
  <link rel="stylesheet" href="css/checkout.css">
  <link rel="stylesheet" href="css/contact.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>

  
<?php
session_start();
?>

<header>

    <div class="header">
        <div class="logo">
            <a href="index.php">
                <img src="imgs/logo.png" alt="Hamilton E-commerce Logo" class="logo-img">
            </a>
        </div>
        <h1>Hamilton E-commerce</h1>
        <div class="SearchBar">
            <input type="text" placeholder="Clothes">
            <button type="button">Search</button>
        </div>
    </div>

    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="products.php">Products</a></li>
            <li><a href="about.php">About Us</a></li>
            <li><a href="checkout.php">Checkout</a></li>
            <li><a href="contact.php">Contact</a></li>
            <?php if (isset($_SESSION['user_id'])): ?>
                <li><a href="logout.php">Logout</a></li>
            <?php else: ?>
                <li><a href="auth.php">SignIn</a></li>
            <?php endif; ?>
        </ul>
    </nav>
    <div class="user-welcome">
            <?php if (isset($_SESSION['first_name'])): ?>
                <span>&nbsp;&nbsp;&nbsp;Welcome <?php echo htmlspecialchars($_SESSION['first_name']); ?></span>
            <?php endif; ?>
        </div>
</header>


  
  <main>
    <div class="checkout-container">
      <h2>Checkout</h2>
      
      <div class="checkout-details">
        <section class="billing-info">
          <h3>Billing Information</h3>
          <form action="process_checkout.php" method="POST">
            <label for="fullName">Full Name</label>
            <input type="text" id="fullName" name="fullName" required>

            <label for="email">Email</label>
            <input type="email" id="email" name="email" required>

            <label for="address">Address</label>
            <input type="text" id="address" name="address" required>

            <label for="city">City</label>
            <input type="text" id="city" name="city" required>

            <label for="postalCode">Postal Code</label>
            <input type="text" id="postalCode" name="postalCode" required>

            <label for="phone">Phone Number</label>
            <input type="tel" id="phone" name="phone" required>
          </form>
        </section>

        <section class="payment-info">
          <h3>Payment Information</h3>
          <label for="cardName">Cardholder Name</label>
          <input type="text" id="cardName" name="cardName" required>

          <label for="cardNumber">Card Number</label>
          <input type="text" id="cardNumber" name="cardNumber" required>

          <label for="expiryDate">Expiry Date</label>
          <input type="text" id="expiryDate" name="expiryDate" placeholder="MM/YY" required>

          <label for="cvv">CVV</label>
          <input type="text" id="cvv" name="cvv" required>
        </section>

        <section class="order-summary">
          <h3>Order Summary</h3>
          <p><strong>Subtotal:</strong> $100.00</p>
          <p><strong>Shipping:</strong> $5.00</p>
          <p><strong>Total:</strong> $105.00</p>
          <button type="submit" class="place-order-button">Place Order</button>
        </section>
      </div>
    </div>

    <section class="gallery">

        <div class="gallery-images">
          <img src="images/store1.jpg" alt="Store image 1">
          <img src="images/store6.jpg" alt="Store image 2">
          
        </div>
      </section>
      
  </main>

  

  
  <footer>
    <div class="Footer">
      <div class="Footer-links">
        <h5>Quick Links</h5>
        <ul>
          <li><a href="index.php">Home</a></li>
          <li><a href="products.php">Products</a></li>
          <li><a href="about.php">About Us</a></li>
          <li><a href="contact.php">Contact</a></li>
        </ul>
      </div>
      <div class="footer-contact">
        <h5>Contact Us</h5>
        <p>123 Street, Hamilton, ON</p>
        <p>+1 123 000 7800</p>
      </div>
      
      <div class="footer-logo">
        <a href="index.php">
          <img src="imgs/logo.png" alt="Hamilton E-commerce Logo" class="logo-img">
        </a>
      </div>
      <div class="footer-social">
        <h5>Follow Us</h5>
        <a href="https://facebook.com" target=""><i class="fab fa-facebook"></i></a>
        <a href="https://twitter.com" target=""><i class="fab fa-twitter"></i></a>
        <a href="https://instagram.com" target=""><i class="fab fa-instagram"></i></a>
        <a href="https://linkedin.com" target=""><i class="fab fa-linkedin"></i></a>
      </div>
    </div>
  </footer>

</body>
</html>
