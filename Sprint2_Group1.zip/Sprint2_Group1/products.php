<?php
session_start();
$conn = new mysqli('localhost', 'root', '', 'store_db');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize search and sort variables
$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
$sort = isset($_GET['sort']) ? $conn->real_escape_string($_GET['sort']) : '';

// Base SQL query
$sql = "SELECT * FROM products WHERE title LIKE '%$search%'";

// Add sorting to the SQL query based on the user's selection
switch ($sort) {
    case 'price_low_high':
        $sql .= " ORDER BY price ASC";
        break;
    case 'price_high_low':
        $sql .= " ORDER BY price DESC";
        break;
    case 'a_z':
        $sql .= " ORDER BY title ASC";
        break;
    case 'z_a':
        $sql .= " ORDER BY title DESC";
        break;
    default:
        break;
}

$result = $conn->query($sql);

// Initialize the cart if not already set
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: auth.php");
    exit();
}

// Add to cart functionality
if (isset($_GET['action']) && $_GET['action'] == 'add' && isset($_GET['id'])) {
    $product_id = $_GET['id'];
    $user_id = $_SESSION['user_id'];

    // Check if the product already exists in the cart for this user
    $check_query = "SELECT * FROM cart WHERE user_id = $user_id AND product_id = $product_id";
    $check_result = $conn->query($check_query);

    if ($check_result->num_rows > 0) {
        $update_query = "UPDATE cart SET quantity = quantity + 1 WHERE user_id = $user_id AND product_id = $product_id";
        $conn->query($update_query);
    } else {
        $insert_query = "INSERT INTO cart (user_id, product_id, quantity) VALUES ($user_id, $product_id, 1)";
        $conn->query($insert_query);
    }

    header("Location: cart.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Listings</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/product.css">
</head>
<body>

<header>
    <div class="header">
        <div class="logo">
            <a href="index.php">
                <img src="imgs/logo.png" alt="Hamilton E-commerce Logo" class="logo-img">
            </a>
        </div>
        <h1>Hamilton E-commerce</h1>
        <div class="SearchBar">
            <input type="text" placeholder="Clothes">
            <button type="button">Search</button>
        </div>
    </div>

    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="products.php">Products</a></li>
            <li><a href="checkout.php">Checkout</a></li>
            <li><a href="about.php">About Us</a></li>
            <li><a href="contact.php">Contact</a></li>
            <?php if (isset($_SESSION['user_id'])): ?>
                <li><a href="logout.php">Logout</a></li>
            <?php else: ?>
                <li><a href="auth.php">SignIn</a></li>
            <?php endif; ?>
        </ul>
    </nav>
    <div class="user-welcome">
        <?php if (isset($_SESSION['first_name'])): ?>
            <span>&nbsp;&nbsp;&nbsp;Welcome <?php echo htmlspecialchars($_SESSION['first_name']); ?></span>
        <?php endif; ?>
    </div>
</header>

<div class="container">
    <h1>Products</h1>

    <!-- Search and Sort Form -->
    <form method="get" action="products.php" class="search-sort-form">
        <input type="text" name="search" placeholder="Search products..." value="<?php echo htmlspecialchars($search); ?>">
        <select name="sort">
            <option value="">Sort By</option>
            <option value="price_low_high" <?php if ($sort == 'price_low_high') echo 'selected'; ?>>Price: Low to High</option>
            <option value="price_high_low" <?php if ($sort == 'price_high_low') echo 'selected'; ?>>Price: High to Low</option>
            <option value="a_z" <?php if ($sort == 'a_z') echo 'selected'; ?>>A to Z</option>
            <option value="z_a" <?php if ($sort == 'z_a') echo 'selected'; ?>>Z to A</option>
        </select>
        <button type="submit">Search</button>
    </form>

    <div class="product-grid">
        <?php while ($row = $result->fetch_assoc()): ?>
            <div class="product">
                <img src="images/<?php echo $row['image']; ?>" alt="<?php echo htmlspecialchars($row['title']); ?>">
                <h2><?php echo htmlspecialchars($row['title']); ?></h2>
                <p>Price: $<?php echo number_format($row['price'], 2); ?></p>
                <a href="product_detail.php?id=<?php echo $row['id']; ?>">View Details</a>
                <a href="products.php?action=add&id=<?php echo $row['id']; ?>" class="add-to-cart-button">Add to Cart</a>
            </div>
        <?php endwhile; ?>
    </div>
</div>

<footer>
    <div class="Footer">
      <div class="Footer-links">
        <h5>Quick Links</h5>
        <ul>
          <li><a href="index.php">Home</a></li>
          <li><a href="products.php">Products</a></li>
          <li><a href="">About Us</a></li>
          <li><a href="">Contact</a></li>
        </ul>
      </div>
      <div class="footer-contact">
        <h5>Contact Us</h5>
        <p>123 Street, Hamilton, ON</p>
        <p>+1 123 000 7800</p>
      </div>
      <div class="footer-logo">
        <a href="index.html">
          <img src="imgs/logo.png" alt="Hamilton E-commerce Logo" class="logo-img">
        </a>
      </div>
      <div class="footer-social">
        <h5>Follow Us</h5>
        <a href="https://facebook.com" target=""><i class="fab fa-facebook"></i></a>
        <a href="https://twitter.com" target=""><i class="fab fa-twitter"></i></a>
        <a href="https://instagram.com" target=""><i class="fab fa-instagram"></i></a>
        <a href="https://linkedin.com" target=""><i class="fab fa-linkedin"></i></a>
      </div>
    </div>
</footer>
  
</body>
</html>

<?php
$conn->close();
?>
